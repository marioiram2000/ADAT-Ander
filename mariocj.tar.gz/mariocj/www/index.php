<?php
include 'header.php';
?>
<div class="container-fluid">
    <div class="row m-5">

        <div class="col-12 col-md-8">
            <?php
            include 'charactersTable.php';
            ?>      
        </div>      
        <div class="col-12 col-md-4" id="cardContainer">
            <img src="data/images/comics.jpg" alt="avengers image" width="100%" class="mt-5"/>
        </div>
    </div>
</div>
<div class="modal" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content" id="modalContent">

        </div>
    </div>
</div>
<?php
include 'footer.php';
?>