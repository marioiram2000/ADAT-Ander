<?php
include './dataBase/conection.php';
include './dataBase/bbdd.php';
$id = $_GET['id'];
$personaje = getPersonajeByID($conn, $id);
if ($personaje['genero'] == 0) {
    $personaje['genero'] = "Femenino";
} else {
    $personaje['genero'] = "Masculino";
}
?>
<div class="card mx-auto characterCard" style="width:400px">
    <img class="card-img-top" src="data/images/marvel/<?php echo $personaje['imagen'] ?>" alt="Imagen del personaje">
    <div class="card-body">
        <h4 class="card-title list-group-item characterCard_title" id="characterCardId"><?php echo $personaje['nombre'] ?></h4>
        <ul class="list-group list-group-flush">
            <li class="list-group-item card-text characterCard_item" data-bs-toggle="modal" data-bs-target="#myModal" onClick="openModal('popularidad', <?php echo $personaje['ID'] ?>)">
                <span class="h6">Popularidad: </span><?php echo $personaje['popularidad'] ?>
            </li>
            <li class="list-group-item card-text">
                <span class="h6">Alineación:  </span><?php echo $personaje['alineacion'] ?>
            </li>
            <li class="list-group-item card-text">
                <span class="h6">Género:  </span><?php echo $personaje['genero'] ?>
            </li>
            <li class="list-group-item card-text characterCard_item" data-bs-toggle="modal" data-bs-target="#myModal" onClick="openModal('altura', <?php echo $personaje['ID'] ?>)">
                <span class="h6">Altura:  </span><?php echo $personaje['altura'] ?>m
            </li>
            <li class="list-group-item card-text characterCard_item" data-bs-toggle="modal" data-bs-target="#myModal" onClick="openModal('peso', <?php echo $personaje['ID'] ?>)">
                <span class="h6">Peso:  </span><?php echo $personaje['peso'] ?>kg
            </li>
            <li class="list-group-item card-text characterCard_item" data-bs-toggle="modal" data-bs-target="#myModal" onClick="openModal('fuerza', <?php echo $personaje['ID'] ?>)">
                <span class="h6">Fuerza:  </span><?php echo $personaje['fuerza'] ?>
            </li>
            <li class="list-group-item card-text characterCard_item" data-bs-toggle="modal" data-bs-target="#myModal" onClick="openModal('velocidad', <?php echo $personaje['ID'] ?>)">
                <span class="h6">Velocidad:  </span><?php echo $personaje['velocidad'] ?>
            </li>
        </ul> 
    </div>
</div>
