<?php
$filter = "Todos";
if (isset($_POST['submitTodos'])) {
    $filter = "Todos";
}
if (isset($_POST['submitBuenos'])) {
    $filter = "Bueno";
}
if (isset($_POST['submitMalos'])) {
    $filter = "Malo";
}
if (isset($_POST['submitNeutrales'])) {
    $filter = "Neutral";
}
$personajes = getPersonajesForTable($conn, $filter);

?>
<div class="btn-group mb-2">
    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']?>">
        <input type='submit' name="submitTodos" value="Todos" class="btn btn-dark text-danger"/>
        <input type='submit' name="submitBuenos" value="Buenos" class="btn btn-dark text-danger"/>
        <input type='submit' name="submitMalos" value="Malos" class="btn btn-dark text-danger"/>
        <input type='submit' name="submitNeutrales" value="Neutrales" class="btn btn-dark text-danger"/>
    </form>
</div> 
<table class="table table-hover charactersTable">
    <thead class="charactersTable_head text-danger">
        <tr class="bg-dark">
            <th>Popularidad</th>
            <th>Nombre</th>
            <th>Sexo</th>
            <th>Procedencia</th>
            <th>Alineación</th>
        </tr>
    </thead>
    <tbody class="charactersTable_body" id="charactersTable_body"> 
        <?php
        foreach ($personajes as $personaje) {
            if ($filter == "Todos" || $filter == $personaje['alineacion']) {
                echo "<tr class='charactersTable_row' onclick='showCharacterCard(" . $personaje['ID'] . ")'>";
                echo "<td>" . $personaje['popularidad'] . "</td>";
                echo "<td>" . $personaje['nombre'] . "</td>";
                if ($personaje['genero'] == "0") {
                    echo "<td>Femenino</td>";
                } else {
                    echo "<td>Masculino</td>";
                }
                echo "<td>" . $personaje['procedencia'] . "</td>";
                echo "<td>" . $personaje['alineacion'] . "</td>";
                echo '</tr>';
            }
        }
        ?>
    </tbody>
</table>