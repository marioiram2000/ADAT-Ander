<?php

function getPersonajesForTable($conn) {
    $sql = "SELECT personajes.ID, personajes.nombre, personajes.popularidad, personajes.alineacion AS alinCod, personajes.genero, personajes.procedencia, alineacion.alineacion "
            . "FROM personajes, alineacion "
            . "WHERE alineacion.codAlineacion = personajes.alineacion "
            . "ORDER BY popularidad; ";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        return $result;
        /*
          while ($personaje = $result->fetch_assoc()) {
          echo "id: " . $personaje["ID"] . " - Name: " . $personaje["nombre"] . " " . $personaje["popularidad"]. " " . $personaje["alinCod"]. " " . $personaje["genero"]. " " . $personaje["procedencia"]. " " . $personaje["alineacion"] . "<br>";
          }
         * 
         */
    } else {
        echo "SIN RESULTADOS";
    }
}

function getPersonajeByID($conn, $id) {
    $sql = "SELECT personajes.ID, personajes.nombre, personajes.popularidad, personajes.alineacion AS alinCod, personajes.genero,"
            . " personajes.procedencia, personajes.altura, personajes.peso, personajes.inteligencia, personajes.fuerza,"
            . " personajes.velocidad, personajes.imagen, alineacion.alineacion "
            . "FROM personajes, alineacion "
            . "WHERE alineacion.codAlineacion = personajes.alineacion "
            . "AND personajes.ID = " . $id;
    $result = $conn->query($sql);
    if ($result->num_rows == 1) {
        return $result->fetch_assoc();
    } else {
        echo 'ERROR';
    }
}

function getPersonajes() {
    $sql = "SELECT personajes.ID, personajes.nombre, personajes.popularidad, personajes.alineacion AS alinCod, personajes.genero,"
            . " personajes.procedencia, personajes.altura, personajes.peso, personajes.inteligencia, personajes.fuerza,"
            . " personajes.velocidad, personajes.imagen, alineacion.alineacion "
            . "FROM personajes, alineacion "
            . "WHERE alineacion.codAlineacion = personajes.alineacion "
            . "ORDER BY popularidad; ";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        return $result;
        while ($row = $result->fetch_assoc()) {
            echo "id: " . $row["id"] . " - Name: " . $row["firstname"] . " " . $row["lastname"] . "<br>";
        }
    } else {
        echo "SIN RESULTADOS";
    }
}

function getCampo($conn, $campo, $id) {
    $sql = "SELECT $campo, nombre from personajes WHERE ID != $id ORDER BY $campo";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        return $result;
    } else {
        echo 'ERROR';
    }
}

function checkUsuario($conn, $username, $pass) {
//$pass = hash("SHA-512", $pass);
    $sql = "SELECT usuario FROM usuarios where usuario = '$username' AND password = '$pass'";
    $result = $conn->query($sql);
    if ($result->num_rows == 1) {
        return true;
    }
    return false;
}

function getLastId($conn) {
    $sql = "SELECT MAX(ID) as ID FROM personajes";
    $result = $conn->query($sql);
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        return $row['ID']+1;
    }
}

function insertPersonaje($conn, $nombre, $popularidad, $alineacion, $genero, $procedencia, $altura, $peso, $inteligencia, $fuerza, $velocidad, $imagen) {
    $id = getLastId($conn);
    $sql = "INSERT INTO personajes "
            . "(ID, nombre, popularidad, alineacion, genero, procedencia, altura, peso, inteligencia, fuerza, velocidad, imagen) "
            . "VALUES ($id, '$nombre', $popularidad, $alineacion, $genero, '$procedencia', $altura, $peso, $inteligencia, $fuerza, $velocidad, '$imagen')";
    $result = $conn->query($sql);
    /*
      $sql = "INSERT INTO personajes
      (ID, nombre, popularidad, alineacion, genero, procedencia, altura, peso, inteligencia, fuerza, velocidad, imagen)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      $stmt = $conn->prepare($sql);
      $id = getLastId($conn);
      $stmt->bind_param("isiiisiiiiis", $id, $nombre, $popularidad, $alineacion, $genero, $procedencia, $altura, $peso, $inteligencia, $fuerza, $velocidad, $imagen);
      $stmt->execute();
      $stmt->close();
     */
}

function updatePersonaje($conn, $nombre, $popularidad, $alineacion, $genero, $procedencia, $altura, $peso, $inteligencia, $fuerza, $velocidad, $imagen, $id) {
    $sql = "UPDATE personajes "
            . "SET nombre = '$nombre', popularidad = $popularidad, alineacion = $alineacion,"
            . " genero = $genero, procedencia = '$procedencia', altura = $altura, peso = $peso,"
            . " inteligencia = $inteligencia, fuerza = $fuerza, velocidad = $velocidad, imagen = '$imagen'"
            . "WHERE ID = $id";
    if ($conn->query($sql) === TRUE) {
        //echo "Record updated successfully";
    } else {
        //echo "Error updating record: " . $conn->error;
    }
    /*
    $sql = "UPDATE personajes "
            . "SET nombre = ?, popularidad = ?, alineacion = ?, genero = ?, procedencia = ?, altura = ?, peso = ?, inteligencia = ?, fuerza = ?, velocidad = ?, imagen = ?"
            . "WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("siiisiiiiisi", $nombre, $popularidad, $alineacion, $genero, $procedencia, $altura, $peso, $inteligencia, $fuerza, $velocidad, $imagen, $id);
    $stmt->execute();
    $stmt->close();
     * 
     */
}

function deletePersonaje($conn, $id) {
    $sql = "DELETE FROM personajes WHERE ID = $id";
    if ($conn->query($sql) === TRUE) {
        //echo "Deleted successfully";
    } else {
        //echo "Error deleting record: " . $conn->error;
    }
}
