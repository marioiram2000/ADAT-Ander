<!DOCTYPE html>
<?php
include './dataBase/conection.php';
include './dataBase/bbdd.php';
session_start();
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="data/bootstrap-5.1.3-dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="styles/styles.css">
        <script src="data/bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>
        <title>MARVEL COMICS</title>
        <script>
            function showCharacterCard(id) {
                const xmlhttp = new XMLHttpRequest();
                xmlhttp.onload = function () {
                    document.getElementById("cardContainer").innerHTML = this.responseText;
                }
                xmlhttp.open("GET", "characterCard.php?id=" + id);
                xmlhttp.send();
            }

            function openModal(campo, idPersonaje) {
                const xhttp = new XMLHttpRequest();
                xhttp.onload = function () {
                    document.getElementById("modalContent").innerHTML = this.responseText;
                }
                xhttp.open("GET", "modalBody.php?campo=" + campo + "&idPersonaje=" + idPersonaje, false);
                xhttp.send();
            }
            
            function filter() {
                select = document.getElementById('select');
                if(select!=null){
                    seleccionado = select.options[select.options.selectedIndex].text;
                filter = seleccionado;
                }else{
                    filter = "todos";
                }                
                const xhttp = new XMLHttpRequest();
                xhttp.onload = function () {
                    document.getElementById("charactersTable_body").innerHTML = this.responseText;
                }
                xhttp.open("GET", "charactersTableBody.php?filter=" + filter, false);
                xhttp.send();
            }
        </script>
    </head>
    <body>
        <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
            <div class="container-fluid">
                <a class="navbar-brand text-danger" href="#">
                    MARVEL 
                </a>
            </div>
        </nav> 