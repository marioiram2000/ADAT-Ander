<?php
include './dataBase/conection.php';
include './dataBase/bbdd.php';
$personaje = null;
$campo = null;
$valores = null;
if (isset($_GET['idPersonaje']) && isset($_GET['campo'])) {
    $campo = $_GET['campo'];
    $idPersonaje = $_GET['idPersonaje'];
    $personaje = getPersonajeByID($conn, $idPersonaje);
    $valores = getCampo($conn, $campo, $idPersonaje);
}
?>
<div class="modal-header">
    <h4 class="modal-title"><?php echo $personaje['nombre'] ?></h4>
    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
    <h5 class="text-capitalize"><?php echo $campo ?>:</h5>
    <ul class="list-group list-group-flush">
        <?php
        foreach ($valores as $valor) {
            if($valor[$campo]>$personaje[$campo]){
                echo "<li class='list-group-item'><strong>".$valor['nombre'].":</strong>"
                        . " \"+\" "
                        . "<span class='text-secondary small'> (".$valor['nombre']." tiene más $campo que ".$personaje['nombre'].")</span>"
                    . "</li>";
            }else if($valor[$campo]<$personaje[$campo]){
                echo "<li class='list-group-item'><strong>".$valor['nombre'].":</strong>"
                        . " \"-\""
                        . "<span class='text-secondary small'> (".$valor['nombre']." tiene menos $campo que ".$personaje['nombre'].")</span>"
                    . "</li>";
            }else{
                echo "<li class='list-group-item'><strong>".$valor['nombre'].":</strong>"
                        . " \"=\""
                        . "<span class='text-secondary small'> (".$valor['nombre']." tiene la misma $campo que ".$personaje['nombre'].")</span>"
                    . "</li>";
            }
        }
        ?>
        
    </ul> 
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
</div>