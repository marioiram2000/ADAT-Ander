<?php
include 'header.php';
if (isset($_POST['username']) && isset($_POST['password'])) {
    if (checkUsuario($conn, $_POST['username'], $_POST['password'])) {        
        $_SESSION['user']="admin";
        $_SERVER['PHP_SELF'] = "adminPanel.php";
    } else {
        $_POST['incorrecto'] = true;
    }
}
?>
<div class="card w-25 mx-auto my-5">
    <form class="card-body" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
        <?php if (isset($_POST['incorrecto']) && $_POST['incorrecto']) { ?>
            <div class="text-danger form-group">
                Datos incorrectos
            </div>
        <?php } ?>

        <div class="form-group">
            <label for="username">Nombre de usuario:</label>
            <input type="text" name="username" id="username"  class="form-control" required/>
        </div>
        <div class="form-group pt-3">
            <label for="password">Contraseña:</label>
            <input type="password" name="password" id="password"  class="form-control" required/>
        </div>
        <div class="form-group pt-3">
            <input type="submit" name="submit" value="Entrar" class="btn btn-primary">
        </div>
    </form>
</div>
<?php
include 'footer.php';
?>
