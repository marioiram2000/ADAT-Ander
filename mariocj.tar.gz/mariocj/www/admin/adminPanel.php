<?php
include 'header.php';

if (!isset($_SESSION['user']) && $_SESSION['user'] != 'admin') {
    $_SERVER['PHP_SELF'] = "admin/index.php";
}

$mensaje = "";

if (isset($_POST['update']) || isset($_POST['delete'])) {
    $personajes = getPersonajesForTable($conn);
}

if (isset($_POST['submitBuscarModificar'])) {
    $idPersonaje = $_POST['selectPersonaje'];
    $personaje = getPersonajeByID($conn, $idPersonaje);
    $nombre = $personaje['nombre'];
    $popularidad = $personaje['popularidad'];
    $alineacion = $personaje['alineacion'];
    $genero = $personaje['genero'];
    $procedencia = $personaje['procedencia'];
    $altura = $personaje['altura'];
    $peso = $personaje['peso'];
    $inteligencia = $personaje['inteligencia'];
    $fuerza = $personaje['fuerza'];
    $velocidad = $personaje['velocidad'];
    $imagen = $personaje['imagen'];
}

if (isset($_POST['submitBuscarBorrar'])) {
    $idPersonaje = $_POST['selectPersonaje'];
}

if (isset($_POST['submitInsert']) || isset($_POST['submitUpdate']) || isset($_POST['submitDelete'])) {

    if (isset($_POST['submitInsert'])) {
        $nombre = $_POST['nombre'];
        $popularidad = $_POST['popularidad'];
        $alineacion = $_POST['alineacion'];
        $genero = $_POST['genero'];
        $procedencia = $_POST['procedencia'];
        $altura = $_POST['altura'];
        $peso = $_POST['peso'];
        $inteligencia = $_POST['inteligencia'];
        $fuerza = $_POST['fuerza'];
        $velocidad = $_POST['velocidad'];
        $imagen = basename($_FILES["imagen"]["name"]);
        uploadImg();
        insertPersonaje($conn, $nombre, $popularidad, $alineacion, $genero, $procedencia, $altura, $peso, $inteligencia, $fuerza, $velocidad, $imagen);
        $mensaje = "Insertado correctamente";
    }

    if (isset($_POST['submitUpdate'])) {
        $nombre = $_POST['nombre'];
        $popularidad = $_POST['popularidad'];
        $alineacion = $_POST['alineacion'];
        $genero = $_POST['genero'];
        $procedencia = $_POST['procedencia'];
        $altura = $_POST['altura'];
        $peso = $_POST['peso'];
        $inteligencia = $_POST['inteligencia'];
        $fuerza = $_POST['fuerza'];
        $velocidad = $_POST['velocidad'];
        $imagen = basename($_FILES["imagen"]["name"]);
        $id = $_POST['idPersonaje'];
        uploadImg();
        updatePersonaje($conn, $nombre, $popularidad, $alineacion, $genero, $procedencia, $altura, $peso, $inteligencia, $fuerza, $velocidad, $imagen, $id);
        $mensaje = "Datos actualiozados correctamente";
    }

    if (isset($_POST['submitDelete'])) {
        $id = $_POST['idPersonaje'];
        deletePersonaje($conn, $id);
        $mensaje = "Eliminado correctamente";
    }
}

function uploadImg() {
    $target_dir = "./data/images/marvel/";
    $target_file = $target_dir . basename($_FILES["imagen"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $check = getimagesize($_FILES["imagen"]["tmp_name"]);
    if ($check !== false) {
        //echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        //echo "File is not an image.";
        $uploadOk = 0;
    }

    if (file_exists($target_file)) {
        //echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    if ($_FILES["imagen"]["size"] > 500000) {
        //echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    if ($uploadOk == 0) {
        //echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $target_file)) {
            //echo "The file " . htmlspecialchars(basename($_FILES["imagen"]["name"])) . " has been uploaded.";
        } else {
            //echo "Sorry, there was an error uploading your file.";
        }
    }
}
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12 pt-3">
            <h4 class="text-center"><?php echo $mensaje ?></h4>
        </div>
    </div>
    <div class="row mt-5 p-3 ">
        <div class="col-2">
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
                <div class="btn-group-vertical">
                    <input type="submit" name="insert" class="btn btn-outline-secondary my-1 w-100" value="Insertar un nuevo personaje"/>
                    <input type="submit" name="update" class="btn btn-outline-secondary my-1 w-100" value="Modificar un personaje"/>
                    <input type="submit" name="delete" class="btn btn-outline-secondary my-1 w-100" value="Eliminar un personaje"/>
                </div>
            </form>
        </div>
        <?php if (isset($_POST['update'])) { ?>
            <div class="col-3">
                <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                    <div class="form-group my-1">
                        <label for='selectPersonaje'> Personaje: </label>
                        <select name='selectPersonaje' id='selectPersonaje' class='form-control my-1'>
                            <?php
                            foreach ($personajes as $personaje) {
                                echo "<option value='" . $personaje['ID'] . "'>" . $personaje['nombre'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <input type="submit" name="submitBuscarModificar" value="Buscar personaje" id="submitBuscarModificar" class="btn btn-primary form-control"/>
                </form>
            </div>
        <?php } ?>
        <?php if (isset($_POST['delete'])) { ?>
            <div class="col-3">
                <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                    <div class="form-group my-1">
                        <label for='selectPersonaje'> Personaje: </label>
                        <select name='selectPersonaje' id='selectPersonaje' class='form-control my-1'>
                            <?php
                            foreach ($personajes as $personaje) {
                                echo "<option value='" . $personaje['ID'] . "'>" . $personaje['nombre'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <input type="submit" name="submitBuscarBorrar" value="Buscar personaje" id="submitBuscarBorrar" class="btn btn-primary form-control"/>
                </form>
            </div>
        <?php } ?>
        <div class="col-8">
            <?php if (isset($_POST['insert'])) { ?>
                <div class="card w-50 mx-auto p-3" >
                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>" enctype="multipart/form-data">
                        <div class="form-group my-1">
                            <label for="nombre">Nombre:</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required/>
                        </div>
                        <div class="form-group my-1">
                            <label for="popularidad">Popularidad:</label>
                            <input type="number" name="popularidad" id="popularidad" class="form-control" required"/>
                        </div>
                        <div class="form-group my-1">
                            <label for="alineacion">Alineación:</label>
                            <select name="alineacion" id="alineacion" class="form-control" required>
                                <option value="1">Bueno</option>
                                <option value="2">Malo</option>
                                <option value="3">Neutral</option>
                            </select>
                        </div>
                        <div class="form-group my-1">
                            <label for="">Sexo:</label>
                            <input type="radio" name="genero" id="femenino" value="0" checked="checked" />
                            <label for="femenino">Femenino</label>
                            <input type="radio" name="genero" id="masculino" value="1"/>
                            <label for="femenino">Masculino</label>
                        </div>
                        <div class="form-group my-1">
                            <label for="procedencia">Procedencia:</label>
                            <input type="text" name="procedencia" id="procedencia" class="form-control"  placeholder="Introduce la procedencia" required/>
                        </div>
                        <div class="form-group my-1">
                            <label for="altura">Altura:</label>
                            <input type="number" name="altura" id="altura" class="form-control" required/>
                        </div>
                        <div class="form-group my-1">
                            <label for="peso">Peso:</label>
                            <input type="number" name="peso" id="peso" class="form-control" required/>
                        </div>
                        <div class="form-group my-1">
                            <label for="inteligencia">Inteligencia:</label>
                            <input type="number" name="inteligencia" id="inteligencia" class="form-control" required/>
                        </div>
                        <div class="form-group my-1">
                            <label for="fuerza">Fuerza:</label>
                            <input type="number" name="fuerza" id="fuerza" class="form-control" required/>
                        </div>
                        <div class="form-group my-1">
                            <label for="velocidad">Velocidad:</label>
                            <input type="number" name="velocidad" id="velocidad" class="form-control" required/>
                        </div>
                        <div class="form-group my-1">
                            <label for="imagen">Imagen:</label>
                            <input type="file" name="imagen" id="imagen" class="form-control"/>
                        </div>
                        <div class="form-group mt-3 mb-1">
                            <input type="submit" name="submitInsert" value="Insertar" id="submit" class="btn btn-primary form-control"/>

                        </div>
                    </form>
                </div>
            <?php } ?>
            <?php if (isset($_POST['submitBuscarModificar'])) { ?>
                <div class="card w-50 mx-auto p-3" >
                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>"  enctype="multipart/form-data">
                        <input type="hidden" name="idPersonaje" value="<?php echo $idPersonaje; ?>"/>
                        <div class="form-group my-1">
                            <label for="">Nombre:</label>
                            <input type="text" name="nombre" id="nombre" class="form-control"  placeholder="Introduce el nombre" required value="<?php echo $nombre ?>"/>
                        </div>
                        <div class="form-group my-1">
                            <label for="popularidad">Popularidad:</label>
                            <input type="number" name="popularidad" id="popularidad" class="form-control" required value="<?php echo $popularidad ?>"/>
                        </div>
                        <div class="form-group my-1">
                            <label for="alineacion">Alineación:</label>
                            <select name="alineacion" id="alineacion" class="form-control" required>
                                <option value="1" <?php
            if ($alineacion == 'Bueno') {
                echo 'selected';
            }
                ?>>Bueno</option>
                                <option value="2" <?php
                            if ($alineacion == 'Malo') {
                                echo 'selected';
                            }
                ?>>Malo</option>
                                <option value="3" <?php
                            if ($alineacion == 'Neutral') {
                                echo 'selected';
                            }
                ?>>Neutral</option>
                            </select>
                        </div>
                        <div class="form-group my-1">
                            <label for="">Sexo:</label>
                            <input type="radio" name="genero" id="femenino" value="0" <?php
                            if ($genero == 0) {
                                echo "checked='checked'";
                            }
                ?>/>
                            <label for="femenino">Femenino</label>
                            <input type="radio" name="genero" id="masculino" value="1" <?php
                        if ($genero == 1) {
                            echo "checked='checked'";
                        }
                ?> />
                            <label for="femenino">Masculino</label>
                        </div>
                        <div class="form-group my-1">
                            <label for="procedencia">Procedencia:</label>
                            <input type="text" name="procedencia" id="procedencia" class="form-control"  placeholder="Introduce la procedencia" required value="<?php echo $procedencia ?>"/>
                        </div>
                        <div class="form-group my-1">
                            <label for="altura">Altura:</label>
                            <input type="number" name="altura" id="altura" class="form-control" required value="<?php echo $altura ?>"/>
                        </div>
                        <div class="form-group my-1">
                            <label for="peso">Peso:</label>
                            <input type="number" name="peso" id="peso" class="form-control" required value="<?php echo $peso ?>"/>
                        </div>
                        <div class="form-group my-1">
                            <label for="inteligencia">Inteligencia:</label>
                            <input type="number" name="inteligencia" id="inteligencia" class="form-control" required value="<?php echo $inteligencia ?>"/>
                        </div>
                        <div class="form-group my-1">
                            <label for="fuerza">Fuerza:</label>
                            <input type="number" name="fuerza" id="fuerza" class="form-control" required value="<?php echo $fuerza ?>"/>
                        </div>
                        <div class="form-group my-1">
                            <label for="velocidad">Velocidad:</label>
                            <input type="number" name="velocidad" id="velocidad" class="form-control" required value="<?php echo $velocidad ?>"/>
                        </div>
                        <div class="form-group my-1">
                            <label for="imagen">Imagen:</label>
                            <input type="file" name="imagen" id="imagen" class="form-control" value=""/>
                        </div>
                        <div class="form-group mt-3 mb-1">
                            <input type="submit" name="submitUpdate" value="Actualizar" id="submit" class="btn btn-primary form-control"/>
                        </div>
                    </form>
                </div>
            <?php } ?>
            <?php if (isset($_POST['submitBuscarBorrar'])) { ?>
                <div class="card w-50 mx-auto p-3" >
                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">                        
                        <input type="hidden" name="idPersonaje" value="<?php echo $idPersonaje; ?>"/>
                        <h5><label for='submit'>¿Está seguro de que desea eliminar el personaje?</label></h5>
                        <input type="submit" name="submitDelete" value="Eliminar" id="submit" class="btn btn-primary form-control"/>
                    </form>
                </div>
            <?php } ?>
        </div>
    </div>
</div>


<?php
include 'footer.php';
?>