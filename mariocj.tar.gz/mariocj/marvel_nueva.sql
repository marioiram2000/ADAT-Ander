-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 29-09-2021 a las 10:56:08
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `marvel`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alineacion`
--

CREATE TABLE `alineacion` (
  `codAlineacion` int(1) NOT NULL,
  `alineacion` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `alineacion`
--

INSERT INTO `alineacion` (`codAlineacion`, `alineacion`) VALUES
(1, 'Bueno'),
(2, 'Malo'),
(3, 'Neutral');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personajes`
--

CREATE TABLE `personajes` (
  `ID` int(11) NOT NULL,
  `nombre` text,
  `popularidad` int(11) DEFAULT NULL,
  `alineacion` int(1) DEFAULT NULL,
  `genero` tinyint(1) DEFAULT NULL,
  `procedencia` text,
  `altura` decimal(10,0) DEFAULT NULL,
  `peso` decimal(10,0) DEFAULT NULL,
  `inteligencia` int(11) DEFAULT NULL,
  `fuerza` int(11) DEFAULT NULL,
  `velocidad` int(11) DEFAULT NULL,
  `imagen` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `personajes`
--

INSERT INTO `personajes` (`ID`, `nombre`, `popularidad`, `alineacion`, `genero`, `procedencia`, `altura`, `peso`, `inteligencia`, `fuerza`, `velocidad`, `imagen`) VALUES
(1, 'Spider Man', 1, 1, 1, 'USA', '2', '76', 4, 4, 3, 'spider-man.jpg'),
(2, 'Iron Man', 20, 3, 1, 'USA', '2', '103', 6, 6, 5, 'iron-man.jpg'),
(3, 'Hulk', 18, 3, 1, 'USA', '2', '635', 1, 7, 3, 'hulk.jpg'),
(4, 'Wolverine', 3, 1, 1, 'Canada', '2', '88', 2, 4, 2, 'wolverine.jpg'),
(5, 'Thor', 5, 1, 1, 'Asgard', '2', '290', 2, 7, 7, 'thor.jpg'),
(6, 'Green Goblin', 91, 2, 1, 'USA', '2', '175', 4, 4, 3, 'green-goblin.jpg'),
(7, 'Magneto', 11, 3, 1, 'Germany', '2', '86', 6, 3, 5, 'magneto.jpg'),
(8, 'Thanos', 47, 2, 1, 'Titan', '2', '447', 6, 7, 7, 'thanos.jpg'),
(9, 'Loki', 32, 2, 1, 'Jotunheim', '2', '238', 5, 5, 7, 'loky.jpg'),
(10, 'Doctor Doom', 19, 2, 1, 'Latveria', '2', '188', 6, 4, 5, 'doctor-doom.jpg'),
(11, 'Jean Grey', 8, 1, 0, 'USA', '2', '52', 3, 2, 7, 'jean-grey.jpg'),
(12, 'Rogue', 4, 1, 0, 'USA', '2', '54', 7, 7, 7, 'rogue.jpg'),
(13, 'Storm', 2, 1, 0, 'Kenya', '2', '66', 2, 2, 3, 'storm.jpg'),
(14, 'Nightcrawler', 6, 1, 1, 'Germany', '2', '73', 3, 2, 7, 'nightcrawler.jpg'),
(15, 'Gambit', 7, 1, 1, 'USA', '2', '81', 2, 2, 2, 'gambit.jpg'),
(16, 'Captain America', 9, 1, 1, 'USA', '2', '108', 3, 3, 2, 'captain-america.jpg'),
(17, 'Cyclops', 10, 1, 1, 'USA', '2', '88', 3, 2, 2, 'cyclops.jpg'),
(18, 'Emma Frost', 12, 3, 0, 'USA', '2', '65', 4, 4, 2, 'emma-frost.jpg'),
(19, 'Kitty Pryde', 13, 1, 0, 'USA', '2', '50', 4, 2, 2, 'kitty-pryde.jpg'),
(20, 'Daredevil', 14, 1, 1, 'USA', '2', '91', 3, 3, 2, 'daredevil.jpg'),
(21, 'Punisher', 50, 3, 1, 'USA', '2', '91', 3, 3, 2, 'punisher.jpg'),
(22, 'Silver Surfer', 33, 1, 1, 'Zenn-La', '2', '102', 3, 7, 7, 'silver-surfer.jpg'),
(23, 'Ghost Rider', 86, 1, 1, 'USA', '2', '99', 2, 4, 3, 'ghost-rider.jpg'),
(24, 'Venom', 78, 3, 1, 'USA', '2', '118', 3, 4, 2, 'venom.jpg'),
(25, 'Juggernaut', 76, 3, 1, 'USA', '3', '862', 2, 7, 2, 'juggernaut.jpg'),
(26, 'Professor X', 58, 1, 1, 'USA', '2', '86', 5, 2, 2, 'professor-x.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `usuario` varchar(10) NOT NULL,
  `password` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`usuario`, `password`) VALUES
('admin', 'b0f20c40b516be74bcb5bfc29f54887fada89e9100a1a6e6b7118f61d995f53deb4bebcec8af8f790f09da8cb174ea9c1273257be8af1343dac0825494bad488');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alineacion`
--
ALTER TABLE `alineacion`
  ADD PRIMARY KEY (`codAlineacion`),
  ADD KEY `codAlineacion` (`codAlineacion`);

--
-- Indices de la tabla `personajes`
--
ALTER TABLE `personajes`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alineacion`
--
ALTER TABLE `alineacion`
  MODIFY `codAlineacion` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
